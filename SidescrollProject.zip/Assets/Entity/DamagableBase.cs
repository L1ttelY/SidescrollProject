using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DamagableBase:MonoBehaviour {

	public virtual bool Damage() { return false; }

}
